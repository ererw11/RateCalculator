package com.eemery.android.ratecalculator;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private final static String TAG = MainActivity.class.getSimpleName();

    Spinner acquiredRateSpinner;
    CheckBox taxesIncludedChckBx;
    CheckBox feesIncludedChckBx;
    CheckBox taxesWaivedCheckBx;
    EditText acquiredRateEditText;
    EditText taxesEditText;
    EditText promotionsEditText;
    EditText compensationEditText;
    EditText flexibleRateEditText;
    EditText taxableServiceChargeEditText;
    EditText nonTaxableServiceChargeEditText;
    EditText directlyRemittedTaxEditText;
    Button calculateButton;
    TextView solutionTextView;

    Boolean acquiredSell;
    Boolean taxesInSellRate;
    Boolean feesInSellRate;
    Boolean taxesWaivedRatePlan;

    double acquiredRate;
    double taxes;
    double compensation;
    double promotion;
    double flexibleRate;
    double taxableServiceCharge;
    double nonTaxableServiceCharge;
    double directlyRemittedTax;

    double baseCost;
    double promoAmountCost;
    double costAfterPromo;
    double finalCost;
    double basePrice;
    double promoAmountPrice;
    double priceAfterPromo;
    double compensationOnRate;
    double flexibleRateAmount;
    double taxToHotel;
    double directlyRemittedTaxAmount;
    double feeAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        acquiredRateSpinner = findViewById(R.id.acquired_rate_spinner);
        taxesIncludedChckBx = findViewById(R.id.taxes_included_sell_rate_radio_button);
        feesIncludedChckBx = findViewById(R.id.fees_included_sell_rate_radio_button);
        taxesWaivedCheckBx = findViewById(R.id.taxes_waived_rate_plan_radio_button);
        acquiredRateEditText = findViewById(R.id.acquired_rate_edit_text);
        taxesEditText = findViewById(R.id.taxes_edit_text);
        promotionsEditText = findViewById(R.id.promotion_edit_text);
        compensationEditText = findViewById(R.id.compensation_edit_text);
        flexibleRateEditText = findViewById(R.id.flexible_rate_edit_text);
        taxableServiceChargeEditText = findViewById(R.id.taxable_fee_edit_text);
        nonTaxableServiceChargeEditText = findViewById(R.id.non_taxable_fee_edit_text);
        directlyRemittedTaxEditText = findViewById(R.id.directly_remitted_tax_edit_text);
        calculateButton = findViewById(R.id.calculate_button);
        solutionTextView = findViewById(R.id.solution_text_view);

        acquiredRateSpinner.setOnItemSelectedListener(this);

        List<String> categories = new ArrayList<>();
        categories.add("Sell/LAR");
        categories.add("Net");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        acquiredRateSpinner.setAdapter(dataAdapter);

        // The Calculate button has been pressed
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                retrieveInputVariables();
                testAll();
            }
        });
    }

    // Collect and format the rate variables
    private void retrieveInputVariables() {
        acquiredRate = 0.0;
        taxes = 0.0;
        compensation = 0.0;
        promotion = 0.0;
        flexibleRate = 0.0;
        taxableServiceCharge = 0.0;
        nonTaxableServiceCharge = 0.0;
        directlyRemittedTax = 0.0;

        // Acquired Rate - Required
        if (!TextUtils.isEmpty(acquiredRateEditText.getText().toString())) {
            acquiredRate = Double.parseDouble(acquiredRateEditText.getText().toString());
            Log.i(TAG, "Rate: " + acquiredRate);
        } else {
            acquiredRateEditText.setError("Please enter a rate");
            Log.i(TAG, "Invalid rate");
        }

        // Taxes - Required - Divide by 100 to get %
        if (!TextUtils.isEmpty(taxesEditText.getText().toString())) {
            taxes = Utils.formatDoublePercentage(Double.parseDouble(taxesEditText.getText().toString()) / 100); //Expect the user to enter whole number
            Log.i(TAG, "Taxes: " + taxes);
        } else {
            taxesEditText.setError("Please enter tax amount");
            Log.i(TAG, "Invalid taxes");
        }

        // Compensation - Required - Divide by 100 to get %
        if (!TextUtils.isEmpty(compensationEditText.getText().toString())) {
            compensation = Utils.formatDoublePercentage(Double.parseDouble(compensationEditText.getText().toString()) / 100); //Expect the user to enter whole number
            Log.i(TAG, "Compensation: " + compensation);
        } else {
            compensationEditText.setError("Please enter compensation amount");
            Log.i(TAG, "Invalid compensation");
        }

        // Promotion Amount - Not Required - Divide by 100 to get %
        if (!TextUtils.isEmpty(promotionsEditText.getText().toString())) {
            promotion = Utils.formatDoublePercentage(Double.parseDouble(promotionsEditText.getText().toString()) / 100); //Expect the user to enter whole number;
            Log.i(TAG, "Promotion: " + promotion);
        }

        // Flexible Rate - Not Required - Divide by 100 to get %
        if (!TextUtils.isEmpty(flexibleRateEditText.getText().toString())) {
            flexibleRate = Utils.formatDoublePercentage(Double.parseDouble(flexibleRateEditText.getText().toString()) / 100); //Expect the user to enter whole number;
            Log.i(TAG, "Flexible rate: " + flexibleRate);
        }

        // Taxable Charge - Not Required - Divide by 100 to get %
        // TODO - Single Amount Non-Taxable Charge
        if (!TextUtils.isEmpty(flexibleRateEditText.getText().toString())) {
            taxableServiceCharge = Utils.formatDoublePercentage(Double.parseDouble(taxableServiceChargeEditText.getText().toString()) / 100);
            Log.i(TAG, "Taxable service charge: " + taxableServiceCharge);
        }

        // Non-Taxable Charge - Not Required - Divide by 100 to get %
        // TODO - Single Amount Non-Taxable Charge
        if (!TextUtils.isEmpty(flexibleRateEditText.getText().toString())) {
            nonTaxableServiceCharge = Utils.formatDoublePercentage(Double.parseDouble(nonTaxableServiceChargeEditText.getText().toString()) / 100); //Expect the user to enter whole number;
            Log.i(TAG, "Non-taxable service charge: " + nonTaxableServiceCharge);
        }

        // Directly Remitted Tax - Not Required - Divide by 100 to get %
        if (!TextUtils.isEmpty(flexibleRateEditText.getText().toString())) {
            directlyRemittedTax = Utils.formatDoublePercentage(Double.parseDouble(directlyRemittedTaxEditText.getText().toString()) / 100);
            Log.i(TAG, "Directly remitted tax: " + directlyRemittedTax);
        }

        // Taxes included in sell rate
        if (acquiredSell) {
            taxesInSellRate = taxesIncludedChckBx.isChecked();
            Log.i(TAG, "Taxes included in sell rate: " + taxesInSellRate.toString());
        }

        // Fees included in sell rate
        if (acquiredSell) {
            feesInSellRate = feesIncludedChckBx.isChecked();
            Log.i(TAG, "Fees included in sell rate: " + feesInSellRate.toString());
        }

        // Taxes waived at rate plan level
        taxesWaivedRatePlan = taxesWaivedCheckBx.isChecked();
        Log.i(TAG, "Taxes waived at rate plan level: " + taxesWaivedRatePlan.toString());
    }

    // Calculate the base cost
    private void calculateBaseCost() {
        // Check if taxes are not in rate
        if (!taxesInSellRate || taxesWaivedRatePlan) {
            // In this case we do not remove taxes
            // Check if there are fees to remove
            if (!feesInSellRate) {
                // There are no fees in rate, solve base cost
                baseCost = acquiredRate * (1 - compensation);
                baseCost = Utils.formatDoubleCurrency(baseCost);
                Log.i(TAG, "Base Cost: " + baseCost);
            } else {
                // Must remove the fees first
                double fees = taxableServiceCharge + nonTaxableServiceCharge;
                double rateMinusFees = acquiredRate / (1 + fees);
                // Calculate base cost
                baseCost = rateMinusFees * (1 - compensation);
                baseCost = Utils.formatDoubleCurrency(baseCost);
                Log.i(TAG, "Base Cost: " + baseCost);
            }
        } else {
            // In this case we do remove taxes
            // Check if there are fees to remove
            if (!feesInSellRate) {
                // There are no fees to remove, remove taxes and solve base cost
                double allTaxes = taxes + directlyRemittedTax;
                double rateMinusTaxes = acquiredRate / (1 + allTaxes);
                // Calculate base cost
                baseCost = rateMinusTaxes * (1 - compensation);
                baseCost = Utils.formatDoubleCurrency(baseCost);
                Log.i(TAG, "Base Cost: " + baseCost);
            } else {
                // We must remove both taxes and fees
                // Remove the taxes
                double allTaxes = taxes + directlyRemittedTax;
                double rateMinusTaxes = acquiredRate / (1 + allTaxes);
                // Remove the Fees
                double fees = taxableServiceCharge + nonTaxableServiceCharge;
                double rateMinusTaxesAndFees = rateMinusTaxes / (1 + fees);
                // Calculate base cost
                baseCost = rateMinusTaxesAndFees * (1 - compensation);
                baseCost = Utils.formatDoubleCurrency(baseCost);
                Log.i(TAG, "Base Cost: " + baseCost);
            }
        }
    }

    // Calculate the promotion amount cost
    private void calculatePromoAmountOnCost() {
        promoAmountCost = Utils.formatDoubleCurrency(baseCost * promotion);
        Log.i(TAG, "Promo amount cost: " + promoAmountCost);
    }

    // Calculate the cost without promotion amount
    private void calculateCostAfterPromo() {
        costAfterPromo = Utils.formatDoubleCurrency(baseCost - promoAmountCost);
        Log.i(TAG, "Cost after promo: " + costAfterPromo);
    }

    // Calculate cost after flexible rate and promos
    private void calculateCostAfterFlexAndPromo() {
        finalCost = Utils.formatDoubleCurrency(costAfterPromo - flexibleRateAmount);
        Log.i(TAG, "Final cost: " + finalCost);
    }

    // Calculate the base price
    private void calculateBasePrice() {
        basePrice = Utils.formatDoubleCurrency(baseCost / (1 - compensation));
        Log.i(TAG, "Base price: " + basePrice);
    }

    // Calculate promo amount price
    private void calculatePromoAmountOnPrice() {
        promoAmountPrice = Utils.formatDoubleCurrency(basePrice * promotion);
        Log.i(TAG, "Promo amount price: " + promoAmountPrice);
    }

    // Calculate price without promotion amount
    private void calculatePriceAfterPromo() {
        priceAfterPromo = Utils.formatDoubleCurrency(basePrice - promoAmountPrice);
        Log.i(TAG, "Price after promo: " + priceAfterPromo);
    }

    // Calculate compensation amount
    private void calculateCompensationOnRate() {
        compensationOnRate = Utils.formatDoubleCurrency(priceAfterPromo - finalCost);
        Log.i(TAG, "Compensation on rate: " + compensationOnRate);
    }

    // Calculate flexible rate amount
    private void calculateFlexibleRateAmount() {
        flexibleRateAmount = Utils.formatDoubleCurrency(priceAfterPromo * flexibleRate);
        Log.i(TAG, "Flexible rate amount: " + flexibleRateAmount);
    }

    // Calculate tax to hotel
    private void calculateTaxToHotel() {
        if (!taxesWaivedRatePlan) {
            // In this case, the taxes are not waived at rate plan level
            taxToHotel = Utils.formatDoubleCurrency(finalCost * taxes);
            Log.i(TAG, "Tax to hotel: " + taxToHotel);
        } else {
            // Taxes are waived at rate plan level
            taxToHotel = 0.00;
        }
    }

    // Calculate directly remitted tax amount
    private void calculateDirectlyRemittedTaxAmount() {
        if (!taxesWaivedRatePlan) {
            // Taxes are not waived at rate plan level
            directlyRemittedTaxAmount = Utils.formatDoubleCurrency(finalCost * directlyRemittedTax);
            Log.i(TAG, "Directly remitted tax: " + directlyRemittedTaxAmount);
        } else {
            // Taxes are not waived at rate plan level
            directlyRemittedTaxAmount = 0.0;
        }
    }

    // Calculate fee amount
    private void calculateFeeAmount() {
        double allFees = taxableServiceCharge + nonTaxableServiceCharge;
        feeAmount = Utils.formatDoubleCurrency(priceAfterPromo * allFees);
        Log.i(TAG, "Fees: " + feeAmount);
    }

    // TODO: Remove this test
    private void testAll() {

        calculateBaseCost();
        calculatePromoAmountOnCost();
        calculateCostAfterPromo();
        calculateCostAfterFlexAndPromo();
        calculateBasePrice();
        calculatePromoAmountOnPrice();
        calculatePriceAfterPromo();
        calculateCompensationOnRate();
        calculateFlexibleRateAmount();
        calculateTaxToHotel();
        calculateDirectlyRemittedTaxAmount();
        calculateFeeAmount();


        solutionTextView.setText(String.format("base price: %s\nPromo amount on price: %s\nPrice after promo: %s" +
                        "\nComp on rate: %s\nbase cost: %s\npromo amount on Cost: %s\ncost after promo: %s\nflex amount: %s" +
                        "\ncost after efr and promo: %s\ntaxes to hotel: %s\ndirectly remitted tax: %s\nfee amount: %s",
                basePrice, promoAmountPrice, priceAfterPromo, compensationOnRate, baseCost, promoAmountCost,
                costAfterPromo, flexibleRateAmount, finalCost, taxToHotel, directlyRemittedTaxAmount, feeAmount));
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(i).toString();

        if (item.equalsIgnoreCase("Sell/LAR")) {
            disableInvalidOptions(true);
        } else {
            disableInvalidOptions(false);
        }

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
    }

    private void disableInvalidOptions(boolean b) {
        if (!b) {
            taxesIncludedChckBx.setChecked(false);
            feesIncludedChckBx.setChecked(false);
        }
        acquiredSell = b;
        taxesIncludedChckBx.setEnabled(b);
        feesIncludedChckBx.setEnabled(b);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}