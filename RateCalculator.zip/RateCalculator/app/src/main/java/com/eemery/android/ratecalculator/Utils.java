package com.eemery.android.ratecalculator;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Utils {

    // Format Doubles as currency
    public static double formatDoubleCurrency(double number) {
        NumberFormat format = new DecimalFormat("###.00");
        return Double.parseDouble(format.format(number));
    }

    public static double formatDoublePercentage(double number) {
        NumberFormat format = new DecimalFormat("#.000");
        return Double.parseDouble(format.format(number));
    }
}
